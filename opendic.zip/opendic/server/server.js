const express = require('express');
const app = express();
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const apiRouter = require('./routers/api');
require('dotenv').config();

const limiter = rateLimit({
	windowMs: 1000 * 60,
	max: 40, 
})

app.use(limiter);
app.use(cookieParser());
app.use(express.static('../public'));
app.use(express.urlencoded({ extended:true }));
app.use(express.json());

app.use('/api', apiRouter);

app.use((err, req, res , next) => {
    console.log(err);
    res.status(500).json({ 'msg' : 'Internal Server Error' });
});

app.get('*',(req, res) => {
    res.status(404).json({ error:'404 Not Found' });
});

app.listen(4000);