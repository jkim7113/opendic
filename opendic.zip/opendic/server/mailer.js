const nodemailer = require('nodemailer');
require('dotenv').config();

const mailer = {

    send : (target, code) => {

         const link = `http://localhost:4000/api/signup/verify/${code}`;

         const transporter = nodemailer.createTransport({
            service: 'gmail',
            host: "smtp.google.com",
            secure: false,
            port: 587,
            auth: {
                type: 'OAuth2',
                user: process.env.EMAIL_ID,
                clientId: process.env.OAUTH_CLIENT_ID,
                clientSecret: process.env.OAUTH_CLIENT_SECRET,
                refreshToken: process.env.OAUTH_TOKEN,
            },
         });

         const options = {
            from: process.env.EMAIL_ID,
            to: target,
            subject: 'Verify Your Account',
            html: 
            `<p>Thank you for signing up for OpenDictionary.</p>
            <p>In order to start using your account, please click the link below within 5 minutes.</p>
            <a href=${link}>Verify Your Account</a>
            <p>If you can't click the link, please copy and paste the following URL into your web browser.</p>
            <p>${link}</p>
            `,
         }

        transporter.sendMail(options);
    }
}

module.exports = mailer;