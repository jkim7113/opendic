const jwt = require('./jwt'); 
require('dotenv').config();

const auth = () => {
    return (req, res, next) => {
    // const accessToken = req.header('x-access-token');
    // const refreshToken = req.header('x-refresh-token');
    const accessToken = req.cookies.accessToken;
    
    try{ // Check if the access token is valid
        const decoded = jwt.verifyAccessToken(accessToken);
        req.userId = decoded.id;
        req.auth = true;
        next();
    } catch(err) {// If not
        if(String(err).slice(0,17) === 'TokenExpiredError'){ //If the access token does exist
            return res.status(400).json({ msg : 'TokenExpiredError' });     
        } 
        
        // If the access token is corrupted
        return res.status(400).json({ msg : 'Access Denied' });
    }
    }
}

module.exports = auth;