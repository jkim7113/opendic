const express = require('express');
const mysql = require('mysql');
const router = express.Router();
const mailer = require('../mailer');
const jwt = require('../jwt');
const bcrypt = require('bcrypt');
const auth = require('../auth');
const sanitizeHTML = require('sanitize-html');
require('dotenv').config();

const saltRounds = 12;
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: process.env.PW,
    database: 'opendic',
    charset: 'utf8mb4',
    dateStrings: "date"
});

router.post('/auth', (req, res) => {
    const refreshToken = req.cookies.refreshToken;

    try{
        const decoded = jwt.verifyRefreshToken(refreshToken);
        const newAccessToken = jwt.createAccessToken(decoded.id, decoded.username);
        const newRefreshToken = jwt.createRefreshToken(decoded.id, decoded.username);

        res.cookie('accessToken', newAccessToken, {
            httpOnly: true,
        });
        res.cookie('refreshToken', newRefreshToken, {
            maxAge : 1000 * 60 * 60 * 24 * 14, //2 weeks
            httpOnly: true,
        });
        res.json({ msg : 'Tokens Reissued', userId : decoded.id, username: decoded.username });

    } catch {
        res.status(400).json({ msg : 'Invalid Refresh Token' });
    }
});

router.get('/signup/verify/:token', (req, res) => {
    const token = req.params.token;

    // if(jwt.verify(token, process.env.JWT_ACCESS_SECRET) === false){
    //     res.status(400).json({ 'msg' : 'Invalid Token' });
    // } else {
    try{
        const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
        db.query(`UPDATE users SET verified = TRUE WHERE id = ? AND verified = FALSE`,[decoded.id], (err, result) => {
            if(err) return res.status(500).json({ 'msg' : 'Unexpected Error Occured' });
            if(result.affectedRows === 0) return res.status(400).send('Your account has already been verified');
            res.status(200).send(`<p>Your verification has successfully been completed. This window will close automatically in 5 seconds.</p>
            <script language='javascript'>setTimeout(() => {window.close()}, 5000);</script>`);
        });
    } catch(err) {
        res.status(400).send(`<p>Your token is invalid. Please check if the token has expired.</p>${err}`);
    }
});

router.post('/signup', (req, res) => {
    const username = req.body.username;
    const email = req.body.email;
    const password = req.body.password;

    const usernameRegEx = /^[a-zA-Z0-9_-]{3,18}$/;
    const emailRegEx = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
    const passwordRegEx = /^(?!((?:[A-Za-z]+)|(?:[~!@#$%^&*()_+=]+)|(?=[0-9]+))$)[A-Za-z\d~!@#$%^&*()_+=]{8,255}$/;

    if(usernameRegEx.test(username) === false){
        res.status(400).json({ 'msg' : 'Invalid Username' });
      } else if(emailRegEx.test(email) === false){
        res.status(400).json({ 'msg' : 'Invalid Email Address' });
      } else if(passwordRegEx.test(password) === false){
        res.status(400).json({ 'msg' : 'Invalid Password' });
      } else { 
        db.query(`SELECT * FROM users WHERE username = ?`,[username], (err ,result) => {
            if(err) throw err;
            if(result[0] !== undefined){
                res.status(400).json({ 'msg' : 'This username is already taken'});
            } else {
                db.query(`SELECT * FROM users WHERE email = ?`,[email], (err, result) => {
                    if(err) return res.status(500).json({ 'msg' : 'Unexpected Error Occured' });
                    if(result[0] !== undefined){
                        res.status(400).json({ 'msg' : 'This email address is already in use'});
                    } else {
                        bcrypt.hash(password, saltRounds, (err,hash) => {
                            if(err) return res.status(500).json({ 'msg' : 'Unexpected Error Occured' });
                            db.query(`INSERT INTO users (username, email, password, regdate) VALUES (?,?,?,NOW())`,[username, email, hash], async (err,result) => {
                                if(err) return res.status(500).json({ 'msg' : 'Unexpected Error Occured' });
                                await mailer.send(email, jwt.createAccessToken(result.insertId));
                                res.status(200).json({ 'resendToken' : jwt.createResendToken(result.insertId) });
                            });
                        })
                    }
                });
            }
        });
    }
});

router.post('/signup/resend', (req, res) => {
    const token = req.body.token;

    try{
        const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
        db.query(`SELECT email, verified FROM users WHERE id = ?`,[decoded.id], async (err, result) => {
            if(err) return res.status(500).json({ 'msg' : 'Unexpected Error Occured' });
            if(result[0].verified === 1) return res.status(400).json({ 'msg' : 'Your account has already been verified' });
            await mailer.send(result[0].email , jwt.createAccessToken(decoded.id));
            res.status(200).json({ 'msg' : 'We sent you an email again. Please check your inbox' });
        });
    } catch {
        res.status(400).json({ 'msg' : 'Your token is invalid. Please check if the token has expired.' });
    }
});

router.post('/login', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    const emailRegEx = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
    const passwordRegEx = /^(?!((?:[A-Za-z]+)|(?:[~!@#$%^&*()_+=]+)|(?=[0-9]+))$)[A-Za-z\d~!@#$%^&*()_+=]{8,255}$/;

    if(emailRegEx.test(email) === false){
        res.status(400).json({ 'msg' : 'Invalid Email Address' });
      } else if(passwordRegEx.test(password) === false){
        res.status(400).json({ 'msg' : 'Invalid Password' });
      } else {
        db.query(`SELECT password, verified, id, username FROM users WHERE email = ?`,[email], async (err, result) => {
            if(err) return res.status(500).json({ 'msg' : 'Unexpected Error Occured' });
            if(result[0] === undefined) return res.status(400).json({ 'msg' : `Couldn't find your account` });
            if(result[0].verified === 0)  return res.status(400).json({ 'msg' : `Your account needs to be verified` });
            const comparison = await bcrypt.compare(password, result[0].password);
            if(comparison){
                const accessToken = jwt.createAccessToken(result[0].id, result[0].username);
                const refreshToken = jwt.createRefreshToken(result[0].id, result[0].username);

                res.cookie('accessToken', accessToken, {
                    httpOnly: true,
                });
                res.cookie('refreshToken', refreshToken, {
                    maxAge : 1000 * 60 * 60 * 24 * 14, //2 weeks
                    httpOnly: true,
                });
                res.status(200).json({ username: result[0].username, userId: result[0].id });
            } else {
                res.status(400).json({ 'msg' : `Wrong password` });
            }
        });
    }
});

router.get('/search/:keyword',(req, res) => {
    const keyword = req.params.keyword.replace(" ","%20");
});

router.get('/words/:word',(req, res) => {
    const word = req.params.word;
});

router.get('/words', (req, res) => {
    const userId = req.query.userId;

    if(userId !== undefined){
        return db.query(`SELECT word, pof, examples, defs, username, date, words.id, users.id AS userId FROM words LEFT JOIN users ON words.author = users.id WHERE users.id = ?`,[userId],(err, words) => {
            if(err) return res.status(500).json({ msg: 'Unexpected Error Occured' });
            res.status(200).json({ words });
        });
    }

    db.query(`SELECT word, pof, examples, defs, username, date, words.id, users.id AS userId FROM words LEFT JOIN users ON words.author = users.id`,(err, words) => {
       if(err) return res.status(500).json({ msg: 'Unexpected Error Occured' });
       res.status(200).json({ words });
    });
});

router.use(auth());

router.post('/words', (req, res) => {
    const userId = req.userId;
    const word = typeof(req.body.word) === 'string' ? (req.body.word.replace(/(\s*)/g, "") !== '' ? req.body.word : '') : '';
    const pof = typeof(req.body.pof) === 'string' ? (req.body.pof.replace(/(\s*)/g, "") !== '' ? req.body.pof : '') : '';
    const definitions = Array.isArray(req.body.definitions) ? req.body.definitions.filter(def => def.replace(/(\s*)/g, "") !== '') : [];
    const examples = Array.isArray(req.body.examples) ? req.body.examples.filter(def => def.replace(/(\s*)/g, "") !== '') : [];
    const validPofs = {
        'noun' : true,
        'verb' : true,
        'adjective' : true,
        'adverb' : true,
        'conjuction' : true,
        'preposition' : true,
        'pronoun' : true,
        'interjection' : true,
        'others' : true,
    }

    if(word !== '' && pof !== '' && definitions.length !== 0){
        
        if(sanitizeHTML(word).length !== word.length) return res.status(400).json({ msg : 'XSS Attempt Detected' });

        if(definitions.filter(def => sanitizeHTML(def).length == def.length).length !== definitions.length)  return res.status(400).json({ msg : 'XSS Attempt Detected' });

        if(examples.filter(ex => sanitizeHTML(ex).length == ex.length).length !== examples.length) return res.status(400).json({ msg : 'XSS Attempt Detected' });

        if(validPofs[pof] !== true){
            console.log(pof !== 'verb' || '');
            return res.status(400).json({ msg : 'Invalid pof value' });
        }
        
        db.query(`INSERT INTO words (word, pof, defs, examples, author, date) VALUES (?,?,?,?,?,NOW())`,[word,pof,definitions.join('`'),examples.join('`'),userId],(err, result)=>{
            if(err) return res.status(500).json({ 'msg' : 'Unexpected Error Occured' });
            res.status(200).json({});
        });

    } else {
        
        res.status(400).json({ msg : 'Required fields are not completely filled out' });

    }
});

module.exports = router;