const jsonwebtoken = require('jsonwebtoken');
require('dotenv').config();

const jwt = {
    createAccessToken : (userId, username) => {
        return jsonwebtoken.sign({
            id: userId,
            username: username,
        },
        process.env.JWT_ACCESS_SECRET,
        {
            expiresIn: '2s',
        });
    },
    
    createRefreshToken : (userId, username) => {
        return jsonwebtoken.sign({
            id: userId,
            username: username,
        },
        process.env.JWT_REFRESH_SECRET,
        {
            expiresIn: '14d',
        });
    },
    
    createResendToken : (userId) => {
        return jsonwebtoken.sign({
            id: userId,
        },
        process.env.JWT_ACCESS_SECRET,
        {
            
        });
    },

    verify : (jwt, secretKey) => {
        return jsonwebtoken.verify(jwt, secretKey);
    },

    decode : (jwt, secretKey) => {
        return jsonwebtoken.verify(jwt, secretKey);
    },

    verifyAccessToken : (jwt) => {
        return jsonwebtoken.verify(jwt, process.env.JWT_ACCESS_SECRET);
    },

    verifyRefreshToken : (jwt) => {
        return jsonwebtoken.verify(jwt, process.env.JWT_REFRESH_SECRET);
    },
    
}

module.exports = jwt;