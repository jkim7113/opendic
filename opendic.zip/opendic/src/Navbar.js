import React, { useRef, useState, useCallback } from 'react';
import { AiFillFolder } from 'react-icons/ai';
import { SiWritedotas } from 'react-icons/si';
import { NavLink } from 'react-router-dom';
import AutoComplete from './AutoComplete';
import Modal from './Modal';
import Add from './Add';

const lockScroll = () => {
  document.querySelector('body').style.overflowY = 'hidden';
}

const Navbar = ({ verified, wordData, setWordData, setKeyword, abortController, relatedKeywords, setVerified, userData, setUserData }) => {
  const [ isModalOpen, setIsModalOpen ] = useState(false);
  const [ errorMsg, setErrorMsg ] = useState('');
  const modal = useRef();

  const openModal = useCallback(() => {
    modal.current.style.display = 'block';
    lockScroll();
  },[modal]);

  
  return (
    <>
    <Add wordData={wordData} setWordData={setWordData} modal={modal} errorMsg={errorMsg} setErrorMsg={setErrorMsg} userData={userData}/>
    <Modal isModalOpen={isModalOpen} setIsModalOpen={setIsModalOpen} errorMsg={errorMsg} setErrorMsg={setErrorMsg} setVerified={setVerified} setUserData={setUserData}/>
    <nav>
      <div id='nav-container'>
      <NavLink to='/'><img src='/images/banner-logo-bc.png' id='title' /></NavLink>
      <AutoComplete setKeyword={setKeyword} 
          abortController={abortController} 
          relatedKeywords={relatedKeywords}
        />
        <div onClick={() => setKeyword('')} id='left-container'>
            {
              verified == true ? 
              <>
              <a onClick={() => {openModal();}}><SiWritedotas className='link' size={30} style={{color:'white'}}/></a>
              <NavLink to={'/users/' + userData.userId}><AiFillFolder className='link' size={30} style={{color:'white'}}/></NavLink>
              </>
              
              : 
              <>
                <button onClick={() => {setIsModalOpen(true); lockScroll();}} type='button' id='nav-sign-in-btn'>Sign In</button>
              </>
            }
        </div>
      </div>
    </nav>
    </>
  )
}

export default Navbar