import React from 'react';
import { VscChromeClose, VscTriangleRight } from 'react-icons/vsc';

const EmailSent = ({ setIsModalOpen, setModalType, resendToken, setErrorMsg }) => {

  const lockScroll = () => {
    document.querySelector('body').style.overflowY = 'scroll';
  }
  
  const handleResendRequest = () => {
    fetch(`/api/signup/resend`,{
  
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            token: resendToken,
          }),
  
    })
    .then(res => res.json())
    .then(json => {
      setErrorMsg(json.msg);
    });
  }

  return (
    <div id='login-inputs-container'>
             <span id='login-header'>
               <p id='login-title'>Verification</p>
               < VscChromeClose onClick={() => {setIsModalOpen(false); lockScroll(); setModalType('login'); setErrorMsg('');}}size='29px' />
             </span>
                <p>Thank you for signing up!</p>
                <p> We have just sent you a verification email to confirm your email address and activate your account.</p>
                <p>Please check your junk mail folder as well as your inbox and follow the instructions.</p>
             <div id='email-sent-link-container'>
                <p className='login-link' onClick={handleResendRequest}><VscTriangleRight size={15}/> Didn't receive an email?</p>
                <p className='login-link' onClick={() => {setModalType('login'); setErrorMsg('');}}><VscTriangleRight size={15}/> Sign In</p>
             </div>
    </div>
  )
}

export default EmailSent