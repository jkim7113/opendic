import React, { useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { GiSpeaker } from 'react-icons/gi';
import { VscPinned, VscEllipsis } from 'react-icons/vsc';
import PostOptions from './PostOptions';

const lockScroll = () => {
  document.querySelector('body').style.overflowY = 'hidden';
}

const Word = ({ wordData, userData }) => {
  const [ isOptionOpen, setIsOptionOpen ] = useState(false); 
  const [ isPostMine, setIsPostMine ] = useState(false);
  
  const audioRef = useRef();
  const { word } = useParams();

  const handleAudioRef = () => {
    audioRef.current.play();
  }

  return (
    <>
    <PostOptions isOptionOpen={isOptionOpen} setIsOptionOpen={setIsOptionOpen} isPostMine={isPostMine}/>
    <div id="word-words-container">
      {
        wordData ? wordData.map((result,index) => (
          <div key={index} className='word-container'>
          
          <div className='word-words-header'>
            <h2 className='words'>{result.word} <i className='pofs'>{result.pof}</i></h2>
            {/* <div className='word-words-btns'>
              <VscPinned size={26}/>
              { result.userId == userData.userId ? <VscEllipsis size={26}/> : ''}
            </div> */}
            { result.userId == userData.userId ? <VscEllipsis size={26} onClick={() => {setIsPostMine(true); setIsOptionOpen(true); lockScroll();}}/> : 
            <VscEllipsis size={26} onClick={() => {setIsPostMine(false); setIsOptionOpen(true); lockScroll();}}/>}
          </div>
          {/* <div className='pronunciations'>
            <GiSpeaker className='speaker-icons' size='22px' onClick={() => handleAudioRef()} />
            <p className='phonetic-spellings'>{
              result.pronunciation.hw == undefined ? `Couldn't find its phonetic spelling :/`
              : result.pronunciation.hw}
            </p>   
          </div> 
    
          <audio ref={audioRef} controls>
            <source src={result.pronunciation.audio} type='audio/mpeg'></source>
          </audio> */}
          <ul className="defs-container">{
           result.defs.split('`').map((def, index) => (
            <li className="defs" key={index}>{def}</li>
           ))
          }</ul>

          <ul className="defs-container">{
            result.examples !== '' ? 
           result.examples.split('`').map((example, index) => (
            <li className="examples" key={index}>"{example}"</li>
           )) : ''
          }</ul>

          <span className='date'><p style={{margin:0}}>by <b>{result.username}</b>, at {result.date.substr(0,16)}</p></span>
          </div>
        ))
        : <h1>No Words Yet</h1>
      }
    </div>
    </>
  )
}

export default Word