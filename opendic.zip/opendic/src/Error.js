import React from 'react'

const Error = ({ type }) => {
  return (
    <div>Error : {type}</div>
  )
}

export default Error