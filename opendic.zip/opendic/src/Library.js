import {React, useEffect } from 'react';
import { Navigate, useParams } from 'react-router-dom';
import Word from './Word';
import getFetch from './services/getFetch';

const Library = ({ wordData, setWordData, verified, setVerified, userData }) => {
  const params = useParams();

  useEffect(() => {
    if(verified === false) return;
    getFetch(`/api/words?userId=${params.userId}`).then(words => setWordData(words.words))
    .catch(err => {
      console.error(err);
    });
  }, []);

  return (
    <div>
      {
        verified === false ?  <Navigate to='/' />: <Word userData={userData} wordData={wordData} />
      }
    </div>
  )
}

export default Library