import React from 'react';
import { VscChromeClose } from 'react-icons/vsc';

const ErrorMsg = ({ msg, setErrorMsg }) => {
  return (
    <>
    {
        msg === '' ? '' : 
        <div id='err-msg-container'>
        <div id='err-msg'>
            {msg}
        </div>
        <VscChromeClose id='err-msg-close-btn' onClick={() => setErrorMsg('')} size='20px'/>
        </div>
    }
    </>
  )
}

export default ErrorMsg