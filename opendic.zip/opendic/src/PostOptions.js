import React from 'react';
const unlockScroll = () => {
    document.querySelector('body').style.overflowY = 'scroll';
 }

const PostOptions = ({ isOptionOpen, setIsOptionOpen, isPostMine }) => {

  return (
    <>
    {
        {
            true: 
                {
                    true:
                    <div className='post-options-container'>
                        <div className='form-background' onClick={() => {setIsOptionOpen(false); unlockScroll();}}></div>
                        <div className='post-options'>
                             <div className='post-options-btns'>Revise</div>
                             <div className='post-options-btns'>Delete</div>
                             <div className='post-options-btns'>Copy Link</div>
                        </div>
                    </div>,

                    false:
                    <div className='post-options-container'>
                        <div className='form-background' onClick={() => {setIsOptionOpen(false); unlockScroll();}}></div>
                    </div>,
                }[isPostMine],
            false: null,

        }[isOptionOpen]
    }
    </>
  )
}

export default PostOptions