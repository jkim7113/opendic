import React,{ useRef, useState, useEffect } from 'react';
import { VscChromeClose, VscEye, VscEyeClosed, VscTriangleRight } from 'react-icons/vsc';

const SignUp = ({ setIsModalOpen, setModalType, setErrorMsg, setResendToken }) => {
    const [ isPasswordVisible, setIsPasswordVisible ] = useState(false);
    const username = useRef();
    const email = useRef();
    const password = useRef();

    const lockScroll = () => {
        document.querySelector('body').style.overflowY = 'scroll';
    }

    useEffect(() => {
        if(password.current){
            if(isPasswordVisible === true){
                password.current.attributes.type.value = 'text';
            } else {
                password.current.attributes.type.value = 'password';
            }
        }
    },[isPasswordVisible]);
  
    const handleSignUpRequest = (e) => {
      e.preventDefault();
      const usernameRegEx = /^[a-zA-Z0-9_-]{3,18}$/;
      const emailRegEx = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
      const passwordRegEx = /^(?!((?:[A-Za-z]+)|(?:[~!@#$%^&*()_+=]+)|(?=[0-9]+))$)[A-Za-z\d~!@#$%^&*()_+=]{8,255}$/;
  
      if(usernameRegEx.test(username.current.value) === false){
        setErrorMsg('Username must be 3 to 18 characters long containing only letters, numbers, dashes, or underscores');
        username.current.focus();
      } else if(emailRegEx.test(email.current.value) === false){
        setErrorMsg('Invalid email address');
        email.current.focus();
      } else if(password.current.value.length < 8){
        setErrorMsg('Password must be at least 8 characters long');
        password.current.focus();
      } else if(passwordRegEx.test(password.current.value) === false){
        setErrorMsg('Password must contain at least two of the following character categories: letters, numbers, and special characters');
        password.current.focus();
      } else {
  
        setErrorMsg('');
  
        fetch(`/api/signup`,{
  
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            username: username.current.value,
            email: email.current.value,
            password : password.current.value,
          }),
  
        })
        .then(res => res.json())
        .then(json => {
          if(json.resendToken){
            setResendToken(json.resendToken);
            setModalType('emailSent');
          } else {
            setErrorMsg(json.msg);
          }
        })
  
      }
    }
  return (
    <div id='login-inputs-container'>
             <span id='login-header'>
               <p id='login-title'>Sign Up</p>
               < VscChromeClose onClick={() => {setIsModalOpen(false); lockScroll(); setModalType('login'); setErrorMsg('');}}size='29px' />
             </span>
             <input ref={username} placeholder='Username' type='text' autoComplete='off' spellCheck='false' className='signup-input' />
             <input ref={email} placeholder='Email Address' type='text' autoComplete='off' spellCheck='false' className='signup-input' />
             <div id='login-password-container'>
               <input ref={password} placeholder='Password' type='password' autoComplete='off' spellCheck='false' id='login-password' />
               {
                 isPasswordVisible === true ? <VscEyeClosed onClick={() => setIsPasswordVisible(false)} id='login-password-toggler' size={23}/> 
                 : <VscEye onClick={() => setIsPasswordVisible(true)} id='login-password-toggler' size={23}/>
               }
             </div>
             <button onClick={(e) => handleSignUpRequest(e)} type='submit' id='login-submit-btn'>Sign Up</button>
             <p className='login-link' onClick={() => {setModalType('login'); setErrorMsg('');}}><VscTriangleRight size={15}/> Already have an account?</p>
    </div>
  )
}

export default SignUp