import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './Navbar';
import Library from './Library';
import Words from './Words';
import Error from './Error';
import Home from './Home'
import { useState, useEffect, createContext } from 'react';

function App() {
  const [ word, setWord ] = useState('');
  const [ wordData, setWordData ] = useState([]);
  const [ keyword, setKeyword ] = useState('');
  const [ relatedKeywords, setRelatedKeywords ] = useState([]);
  const [ verified, setVerified ] = useState(true);
  const [ userData, setUserData ] = useState({
    userId : undefined,
    username : undefined, 
  });
  const [ isLoading, setIsLoading ] = useState(true);
  const abortController = new AbortController();

  useEffect(() => {

    if(keyword == ''){
      setRelatedKeywords([])
    } else {
      fetch(`/api/search/${keyword}`,
      { signal: abortController.signal })
        .then(response => response.json())
        .then(data => {
          setRelatedKeywords(data.results.words);
        })
        .catch(err => {
          console.error(err);
          setRelatedKeywords([]);
      });
    };

  },[keyword]);

  useEffect(() => {

    if(word !== ''){ 
      fetch(`/api/words/${word}`,
        { signal: abortController.signal })
          .then(response => response.json())
          .then(data => {
            setWordData(data);
          })
          .catch(err => {
            console.error(err);
            setWordData([]);
        });
    }
  },[word]);

  useEffect(() => {
  
    fetch(`/api/auth`,{
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then(res => res.json())
    .then(json => {
      if(json.msg === 'Tokens Reissued') {
        setVerified(true);
        setUserData({
          userId : json.userId,
          username : json.username,
        });
      }
      else setVerified(false);
      setIsLoading(false);
    })
    .catch(err => {setVerified(false); console.log(err)});

  },[]);

  return (
    <>
    {
      isLoading === true ? '' : 
      <div className="App">
      <BrowserRouter>
        <Navbar 
          verified={verified}
          setVerified={setVerified}
          wordData={wordData}
          setWordData={setWordData}
          setKeyword={setKeyword} 
          abortController={abortController}
          relatedKeywords={relatedKeywords} 
          userData={userData}
          setUserData={setUserData}
        />
        <Routes>
          <Route path='/' element={<Home userData={userData} setVerified={setVerified} wordData={wordData} verified={verified} setWordData={setWordData}/>} />
          <Route path='/users/:userId' element={<Library userData={userData} setVerified={setVerified} wordData={wordData} verified={verified} setWordData={setWordData}/>} />
          <Route path='/words/:word' element={<Words wordData={wordData} setWord={setWord} />}/>
          <Route path='*' element={<Error type={404}/>}/>
        </Routes>
      </BrowserRouter>
      {
        word == '' ? '' :
        <div id='background' onClick={() => setKeyword('')}></div>
      }
    </div>
    }
    </>
  );
}

export default App;
