import React, { useState, useEffect, useRef } from 'react';
import ErrorMsg from './ErrorMsg';
import Login from './Login';
import SignUp from './SignUp';
import EmailSent from './EmailSent';

const Modal = ({ isModalOpen, setIsModalOpen, errorMsg, setErrorMsg, setVerified, setUserData }) => {
  const [ modalType, setModalType ] = useState('login');
  const [ resendToken, setResendToken ] = useState('');

  const lockScroll = () => {
    document.querySelector('body').style.overflowY = 'scroll';
  }

  return (
    <>
      {
        isModalOpen === false ? '' :
        (
          modalType === 'login' ? 

          <div id='login-modal'>
            <div className='form-background' onClick={() => {setIsModalOpen(false); lockScroll(); setErrorMsg('');}}></div>
            <form id='login-form'>
              <div id='login-left-banner'>
              </div>
              <Login setIsModalOpen={setIsModalOpen} setModalType={setModalType} setUserData={setUserData} setErrorMsg={setErrorMsg} setVerified={setVerified} />
            </form>
            <ErrorMsg msg={errorMsg} setErrorMsg={setErrorMsg}/>
          </div>

         : modalType === 'signup' ?
         <div id='login-modal'>
         <div className='form-background' onClick={() => {setIsModalOpen(false); lockScroll(); setModalType('login'); setErrorMsg('');}}></div>
         <form id='login-form'>
            <div id='login-left-banner'>
            </div>
            <SignUp setIsModalOpen={setIsModalOpen} setModalType={setModalType} setErrorMsg={setErrorMsg} setResendToken={setResendToken} />
         </form>
            <ErrorMsg msg={errorMsg} setErrorMsg={setErrorMsg}/>
         </div>

          : modalType === 'emailSent' ?
         <div id='login-modal'>
         <div className='form-background' onClick={() => {setIsModalOpen(false); lockScroll(); setModalType('login'); setErrorMsg('');}}></div>
         <form id='login-form'>
            <div id='login-left-banner'>
            </div>
            <EmailSent setIsModalOpen={setIsModalOpen} setModalType={setModalType} resendToken={resendToken} setErrorMsg={setErrorMsg} />
         </form>
            <ErrorMsg msg={errorMsg} setErrorMsg={setErrorMsg}/>
         </div> 

          : ''
        )
      }
    </>
  )
}

export default Modal