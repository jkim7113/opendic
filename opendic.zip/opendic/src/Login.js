import React, { useEffect, useRef, useState } from 'react'
import { VscChromeClose, VscEye, VscEyeClosed, VscTriangleRight } from 'react-icons/vsc';

const Login = ({ setIsModalOpen, setModalType, setErrorMsg, setVerified, setUserData }) => {
  const email = useRef();
  const password = useRef();
  const [ isPasswordVisible, setIsPasswordVisible ] = useState(false);

  const emailRegEx = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
  const passwordRegEx = /^(?!((?:[A-Za-z]+)|(?:[~!@#$%^&*()_+=]+)|(?=[0-9]+))$)[A-Za-z\d~!@#$%^&*()_+=]{8,255}$/;

  useEffect(() => {
    if(password.current){
        if(isPasswordVisible === true){
            password.current.attributes.type.value = 'text';
        } else {
            password.current.attributes.type.value = 'password';
        }
    }
  },[isPasswordVisible]);

  const lockScroll = () => {
    document.querySelector('body').style.overflowY = 'scroll';
  }

  const handleLoginRequest = (e) => {
    e.preventDefault();

    if(emailRegEx.test(email.current.value) === false){
      email.current.focus();
      setErrorMsg('Invalid Email Address');
    } else if(passwordRegEx.test(password.current.value) === false){
      password.current.focus();
      setErrorMsg('Invalid Password');
    } else {

      fetch(`/api/login`,{
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email : email.current.value,
        password : password.current.value,
      }),
    }).then(
      res => {
        if(res.status === 200){
          res.json().then(json => {
            setVerified(true);
            setUserData({
              userId : json.userId,
              username : json.username,
            });
            setIsModalOpen(false);
            lockScroll();
            setErrorMsg('');
          });
        } else {
          res.json().then(
            json => {
              if(json.msg === "Couldn't find your account"){
                email.current.focus();
              } else {
                password.current.focus();
              }
              setErrorMsg(json.msg)
            }
          )
        }
      }
    )
    }

  }

  return (
    <div id='login-inputs-container'>
    <span id='login-header'>
      <p id='login-title'>Sign In</p>
      < VscChromeClose onClick={() => {setIsModalOpen(false); lockScroll(); setErrorMsg(''); }}size='29px' />
    </span>
    <input ref={email} placeholder='Email Address' type='text' autoComplete='off' spellCheck='false' id='login-email' />
    <div id='login-password-container'>
      <input ref={password} placeholder='Password' type='password' autoComplete='off' spellCheck='false' id='login-password' />
      {
        isPasswordVisible === true ? <VscEyeClosed onClick={() => setIsPasswordVisible(false)} id='login-password-toggler' size={23}/> 
        : <VscEye onClick={() => setIsPasswordVisible(true)} id='login-password-toggler' size={23}/>
      }
    </div>
    <div id='login-checkbox-container'>
      <input type='checkbox' id='login-checkbox'/><p id='login-checkbox-label'>Remember Me</p>
    </div>
    <button onClick={(e) => handleLoginRequest(e)} type='submit' id='login-submit-btn'>Sign In</button>
    <p className='login-link'><VscTriangleRight size={15} /> Forgot Password?</p>
    <p className='login-link' onClick={() => {setModalType('signup'); setErrorMsg('');}}><VscTriangleRight size={15}/> Don't have an account?</p>
  </div>
  )
}

export default Login