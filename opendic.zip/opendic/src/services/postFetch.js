const postFetch = (target, bodyOption) => {
    const fetcher = async () => {
      console.log(bodyOption);
      const data = await fetch(target, {
        method:"POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: bodyOption !== undefined ? JSON.stringify(bodyOption) : '',
      });

      const json = await data.json();
  
      if(json.msg === 'TokenExpiredError') {
        const requestData = await fetch(`/api/auth`, {
          method:"POST",
          headers: {
            "Content-Type": "application/json",
          },
        });
  
        const requestJson = await requestData.json();
        if(requestJson.msg === 'Tokens Reissued') return fetcher();
      } 
      if(json.status !== 200){
        return json;
      }
        return json;
    } 
    return fetcher();
  }
  
  export default postFetch;