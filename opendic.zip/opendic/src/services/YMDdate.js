const YMDdate = () => {
    const date = new Date();
    return `${date.getFullYear()}-${String(date.getMonth()).length > 1 ?date.getMonth() : '0'+String(date.getMonth()+1)}-${String(date.getDate()).length > 1 ?date.getDate() : '0'+String(date.getDate())} ${String(date.getHours()).length > 1 ? date.getHours() : '0'+String(date.getHours())}:${String(date.getMinutes()).length > 1 ?date.getMinutes() : '0'+String(date.getMinutes())}`;
}

export default YMDdate;