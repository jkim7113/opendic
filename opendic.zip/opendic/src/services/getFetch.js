const getFetch = (target, setVerified) => {
  const fetcher = async () => {
    const data = await fetch(target);
    const json = await data.json();

    if(json.msg === 'TokenExpiredError') {
      const requestData = await fetch(`/api/auth`, {
        method:"POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const requestJson = await requestData.json();
      if(requestJson.msg === 'Tokens Reissued') return fetcher();
    } 
    else return json;
  } 
  return fetcher();
}

export default getFetch;