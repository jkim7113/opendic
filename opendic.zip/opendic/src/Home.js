import {React, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import Word from './Word';
import getFetch from './services/getFetch';

const Home = ({ wordData, setWordData, verified, setVerified, userData }) => {

  useEffect(() => {
    getFetch('/api/words').then(words => setWordData(words.words))
    .catch(err => {
      console.error(err);
    });
  }, []);

  return (
      <Word wordData={wordData} userData={userData}/>
  )
}

export default Home